
public class ConcreteObserver extends Observer {
	private String observerState;
	private String Id;

	ConcreteObserver(String Idt) {
		Id = Idt;
	}
	
	protected void update() {
		System.out.println(Id + " notificado");
		System.out.println("Olá, como vai?");
	}
}
