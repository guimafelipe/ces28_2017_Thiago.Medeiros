import java.util.ArrayList;

public class ConcreteSubject extends Subject {
	private String subjectState;
	
	ConcreteSubject() { Observers = new ArrayList<Observer>(); }
	
	public String getState() {
		return subjectState;
	}
	
	public void setState() {		
		this.Notify();
	}
}