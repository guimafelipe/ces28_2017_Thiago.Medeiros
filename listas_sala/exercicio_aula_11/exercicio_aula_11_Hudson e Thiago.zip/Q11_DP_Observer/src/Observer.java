
abstract class Observer {
	abstract void update();
}
