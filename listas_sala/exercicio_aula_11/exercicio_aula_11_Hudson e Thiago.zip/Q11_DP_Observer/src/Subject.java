import java.util.ArrayList;
import java.util.Iterator;

abstract class Subject {
	protected ArrayList<Observer> Observers;

	public void Attach(Observer obs) {
		Observers.add(obs);
	}
	
	public void Dettach(Observer obs) {
		Iterator<Observer> It = Observers.iterator();
		while(It.hasNext()) {
			Observer search = It.next();
			if(search.equals(obs)) {
				It.remove();
				return;
			}
		}
	}
	
	protected void Notify() {
		for(Observer search: Observers) {
			search.update();
		}
	}
}
