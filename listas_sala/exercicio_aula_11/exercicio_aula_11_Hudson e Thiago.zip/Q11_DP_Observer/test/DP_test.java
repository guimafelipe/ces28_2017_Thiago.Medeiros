import static org.junit.Assert.*;

import org.junit.Test;

public class DP_test {
	@Test
	public void test() {
		ConcreteObserver Obs1 = new ConcreteObserver("Obs1");
		ConcreteObserver Obs2 = new ConcreteObserver("Obs2");
		ConcreteSubject Sub = new ConcreteSubject();
		
		// Primeiro evento:
		System.out.println("Primeiro evento:");
		Sub.Attach(Obs1);
		Sub.Attach(Obs2);
		Sub.setState();
		
		System.out.println("");
		
		// Segundo evento:
		System.out.println("Segundo evento:");
		Sub.Dettach(Obs1);
		Sub.setState();
	}
}
