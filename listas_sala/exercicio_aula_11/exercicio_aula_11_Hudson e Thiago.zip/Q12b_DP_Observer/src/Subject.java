import java.util.Observable;

class Subject extends Observable {
  private String subjectState;

  public String getState() {
	  return subjectState;
  }

  public void setState() {
    setChanged();
    notifyObservers();
  }
}
