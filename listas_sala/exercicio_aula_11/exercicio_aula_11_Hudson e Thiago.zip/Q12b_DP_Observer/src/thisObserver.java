import java.util.Observer;
import java.util.Observable;

public class thisObserver implements Observer {
	private String Id;
	private String observerState;
	
	public thisObserver(String Idt) {
		Id = Idt;
	}
	
	public void update(Observable obs, Object arg) {
		System.out.println(Id + " notificado");
		System.out.println("Olá, como vai?");
	}
}