import static org.junit.Assert.*;

import org.junit.Test;

public class DP_tests {
	@Test
	public void test() {
		Subject sub = new Subject();
		thisObserver Obs1 = new thisObserver("Obs1");
		thisObserver Obs2 = new thisObserver("Obs2");
		
		// Primeiro evento:
		System.out.println("Primeiro evento:");
		sub.addObserver(Obs1);
		sub.addObserver(Obs2);
		sub.setState();
		
		System.out.println("");
		
		// Segundo evento:
		System.out.println("Segundo evento:");
		sub.deleteObserver(Obs1);
		sub.setState();
	}
}
